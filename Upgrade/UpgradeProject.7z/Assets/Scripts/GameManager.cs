﻿using UnityEngine;

public class GameManager : MonoBehaviour
{

    public static int score;
    public static int lives = 3;
    public static bool inGame;

}
